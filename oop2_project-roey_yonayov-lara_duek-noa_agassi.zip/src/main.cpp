#include <SFML/Graphics.hpp>
#include "Objects.h/BaseObject.h"
#include "screenFolder.h/MenuState.h"
#include "Controller.h"


#include "Objects.h/PlayerObject.h"





int main()
{
    Controller c;
    c.run();
   
    return 0;
    
}
