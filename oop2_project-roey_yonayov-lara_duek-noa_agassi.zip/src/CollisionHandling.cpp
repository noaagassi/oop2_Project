#include "CollisionHandling.h"

#include <iostream>
#include <map>
#include <string>
#include <typeinfo>
#include <typeindex>

#include "SoundsHandler.h"

#include "Objects.h/PlayerObject.h"
#include "Objects.h/BushObject.h"
#include "Objects.h/WallObject.h"
#include "Objects.h/PortalObject.h"
#include "Objects.h/TreeObject.h"
#include "Objects.h/LifeGiftObject.h"
#include "Objects.h/FreezeGiftObject.h"
#include"Objects.h/PoisonObject.h"
#include"Objects.h/WeaponGiftObject.h"
#include "Objects.h/BulletObject.h"
#include "Objects.h/BallObject.h"
#include "Objects.h/BombObject.h"
#include "Objects.h/SmallFastEnemyObject.h"
#include "Objects.h/BigSlowEnemyObject.h"
#include "Objects.h/BaseEnemyObject.h"





namespace // anonymous namespace � the standard way to make function "static"
{
    void stopAdvance(sf::FloatRect& subjectBounds, const sf::FloatRect& objectBounds, MovingObject& subject)
    {
        float overlapLeft = subjectBounds.left + subjectBounds.width - objectBounds.left;
        float overlapRight = objectBounds.left + objectBounds.width - subjectBounds.left;
        float overlapTop = subjectBounds.top + subjectBounds.height - objectBounds.top;
        float overlapBottom = objectBounds.top + objectBounds.height - subjectBounds.top;

        bool moveLeft = overlapLeft < overlapRight;
        bool moveUp = overlapTop < overlapBottom;

        float minOverlapX = moveLeft ? overlapLeft : overlapRight;
        float minOverlapY = moveUp ? overlapTop : overlapBottom;

        sf::Vector2f newPosition = subject.getSprite().getPosition();

        if (minOverlapX < minOverlapY) {
            newPosition.x = moveLeft ? objectBounds.left - subjectBounds.width : objectBounds.left + objectBounds.width;
        }
        else {
            newPosition.y = moveUp ? objectBounds.top - subjectBounds.height : objectBounds.top + objectBounds.height;
        }

        subject.setPosition(newPosition);
    }


    

    ////////////////////////////////////////////////////////////////////////////////////
    // primary collision-processing functions
    void playerBush (BaseObject& player, BaseObject& bush)
    {
        PlayerObject& real_player = dynamic_cast<PlayerObject&>(player);
        BushObject&  real_bush  = dynamic_cast<BushObject&>(bush);


        

        real_bush.makeTranslucent();
        real_player.setInBush(true);
    }

    void playerWall (BaseObject& player, BaseObject& wall)
    {
        PlayerObject& real_player = dynamic_cast<PlayerObject&>(player);
        WallObject& real_wall = dynamic_cast<WallObject&>(wall);

        

        sf::FloatRect playerBounds = real_player.getSprite().getGlobalBounds();
        sf::FloatRect wallBounds = real_wall.getSprite().getGlobalBounds();

        stopAdvance(playerBounds, wallBounds, real_player);
    }
    
    
    void playerTree(BaseObject& player, BaseObject& tree)
    {
        PlayerObject& real_player = dynamic_cast<PlayerObject&>(player);
        TreeObject& real_tree = dynamic_cast<TreeObject&>(tree);

        

        sf::FloatRect playerBounds = real_player.getSprite().getGlobalBounds();
        sf::FloatRect treeBounds = real_tree.getSprite().getGlobalBounds();

        stopAdvance(playerBounds, treeBounds, real_player);
    }

    void playerPortal(BaseObject& player, BaseObject& portal)
    {
        PlayerObject& real_player = dynamic_cast<PlayerObject&>(player);
        PortalObject& real_portal = dynamic_cast<PortalObject&>(portal);

       
        SoundsHandler::getInstance().playSound(Sound_Id::PORTAL_ENTER);


        PortalObject* target_portal = real_portal.getRandomPortal();
        sf::Vector2f target_position = target_portal->getSprite().getPosition();
        sf::Vector2f offset(0.f, 40.f);
        target_position += offset;
        real_player.setPosition(target_position);

    }

    void playerLife(BaseObject& player, BaseObject& life)
    {
        PlayerObject& real_player = dynamic_cast<PlayerObject&>(player);
        LifeGiftObject& real_life = dynamic_cast<LifeGiftObject&>(life);
        SoundsHandler::getInstance().playSound(Sound_Id::EXTRA_LIFE);

        real_player.ateLiveGift();

        real_life.toDelete(true);

    }

    void playerFreeze(BaseObject& player, BaseObject& freeze)
    {
        PlayerObject& real_player = dynamic_cast<PlayerObject&>(player);
        FreezeGiftObject& real_freeze = dynamic_cast<FreezeGiftObject&>(freeze);

       
        real_player.isAteFreezeGift();
        real_freeze.toDelete(true);
        SoundsHandler::getInstance().playSound(Sound_Id::FREEZE);


    }

    void playerWeapon(BaseObject& player, BaseObject& weapon)
    {
        PlayerObject& real_player = dynamic_cast<PlayerObject&>(player);
        WeaponGiftObject& real_weapon = dynamic_cast<WeaponGiftObject&>(weapon);

        

        real_weapon.toDelete(true);
        SoundsHandler::getInstance().playSound(Sound_Id::WEAPON_GIFT);
        real_player.weaponGift();
       
    }

    void ballWall(BaseObject& bullet, BaseObject& wall)
    {
        
        BallObject& real_bullet = dynamic_cast<BallObject&>(bullet);
        WallObject& real_wall = dynamic_cast<WallObject&>(wall);
        SoundsHandler::getInstance().playSound(Sound_Id::BALL_HIT);
        
        real_bullet.toDelete(true);

    }
    void ballTree(BaseObject& bullet, BaseObject& tree)
    {

        BallObject& real_bullet = dynamic_cast<BallObject&>(bullet);
        TreeObject& real_tree = dynamic_cast<TreeObject&>(tree);

        
        SoundsHandler::getInstance().playSound(Sound_Id::BALL_HIT);
        
        real_bullet.toDelete(true);

    }


   

    
    void bombTree(BaseObject& bullet, BaseObject& tree)
    {

        BombObject& real_bullet = dynamic_cast<BombObject&>(bullet);
        TreeObject& real_tree = dynamic_cast<TreeObject&>(tree);
        //SoundsHandler::getInstance().playSound(Sound_Id::BOMB_HIT);
        
        real_bullet.toDelete(true);

    }
    
    
    void bombBigEnemy(BaseObject& bomb, BaseObject& enemy)
    {

        BombObject& real_bomb = dynamic_cast<BombObject&>(bomb);
        BigSlowEnemyObject& real_enemy = dynamic_cast<BigSlowEnemyObject&>(enemy);
        SoundsHandler::getInstance().playSound(Sound_Id::BOMB_HIT);
        real_bomb.setObjTexture(Object_ID::EXPLOSION);
        real_enemy.looseLive(2.5);
        real_bomb.toDelete(true);

    }
    void bigEnemyBomb(BaseObject& enemy, BaseObject& bomb)
    {
        bombBigEnemy(bomb, enemy);
    }
    
    void ballBigEnemy(BaseObject& ball, BaseObject& enemy)
    {

        BallObject& real_ball = dynamic_cast<BallObject&>(ball);
        BigSlowEnemyObject& real_enemy = dynamic_cast<BigSlowEnemyObject&>(enemy);
        SoundsHandler::getInstance().playSound(Sound_Id::BALL_HIT);
        
        real_enemy.looseLive(0.2);
        real_ball.toDelete(true);

    }
    void bigEnemyBall(BaseObject& enemy, BaseObject& ball)
    {
        ballBigEnemy(ball, enemy);
    }

    
    void bombSmallEnemy(BaseObject& bomb, BaseObject& enemy)
    {

        BombObject& real_bomb = dynamic_cast<BombObject&>(bomb);
        SmallFastEnemyObject& real_enemy = dynamic_cast<SmallFastEnemyObject&>(enemy);
        SoundsHandler::getInstance().playSound(Sound_Id::BOMB_HIT);
        real_bomb.setObjTexture(Object_ID::EXPLOSION);
        real_enemy.looseLive(3.5);
        real_bomb.toDelete(true);

    }
    void smallEnemyBomb(BaseObject& enemy, BaseObject& bomb)
    {
        bombSmallEnemy(bomb, enemy);
    }
    
    void ballSmallEnemy(BaseObject& ball, BaseObject& enemy)
    {

        BallObject& real_ball = dynamic_cast<BallObject&>(ball);
        SmallFastEnemyObject& real_enemy = dynamic_cast<SmallFastEnemyObject&>(enemy);
        SoundsHandler::getInstance().playSound(Sound_Id::BALL_HIT);
        
        real_enemy.looseLive(0.3);
        real_ball.toDelete(true);

    }
    void smallEnemyBall(BaseObject& enemy, BaseObject& ball)
    {
        ballSmallEnemy(ball, enemy);
    }

    

    void smallEnemyTree(BaseObject& enemy, BaseObject& tree)
    {
        SmallFastEnemyObject& real_enemy = dynamic_cast<SmallFastEnemyObject&>(enemy);
        TreeObject& real_tree = dynamic_cast<TreeObject&>(tree);

        

        sf::FloatRect enemyBounds = real_enemy.getSprite().getGlobalBounds();
        sf::FloatRect treeBounds = real_tree.getSprite().getGlobalBounds();

        stopAdvance(enemyBounds, treeBounds, real_enemy);
    }

    void smallEnemyWall(BaseObject& enemy, BaseObject& wall)
    {
        SmallFastEnemyObject& real_enemy = dynamic_cast<SmallFastEnemyObject&>(enemy);
        WallObject& real_wall = dynamic_cast<WallObject&>(wall);

       

        sf::FloatRect enemyBounds = real_enemy.getSprite().getGlobalBounds();
        sf::FloatRect wallBounds = real_wall.getSprite().getGlobalBounds();

        stopAdvance(enemyBounds, wallBounds, real_enemy);
    }

    void smallEnemyPortal(BaseObject& enemy, BaseObject& portal)
    {
        SmallFastEnemyObject& real_enemy = dynamic_cast<SmallFastEnemyObject&>(enemy);
        PortalObject& real_portal = dynamic_cast<PortalObject&>(portal);

        SoundsHandler::getInstance().playSound(Sound_Id::PORTAL_ENTER);


        PortalObject* target_portal = real_portal.getRandomPortal();
        sf::Vector2f target_position = target_portal->getSprite().getPosition();
        sf::Vector2f offset(0.f, 40.f);
        target_position += offset;
        real_enemy.setPosition(target_position);

    }


    void smallEnemyPoison(BaseObject& enemy, BaseObject& poison)
    {
       
    }


    void playerLaser(BaseObject& player, BaseObject& laser)
    {

        PlayerObject& real_player = dynamic_cast<PlayerObject&>(player);
        LaserObject& real_laser= dynamic_cast<LaserObject&>(laser);
        SoundsHandler::getInstance().playSound(Sound_Id::POISON_HIT);

        real_player.setlife(-(real_laser.getFireRate()));
        real_laser.toDelete(true);

    }
    void laserPlayer(BaseObject& laser, BaseObject& player)
    {
        playerLaser(player, laser);
    }




    void nothingToDo(BaseObject& a, BaseObject& b)
    {

    }
    
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////
    using HitFunctionPtr = void (*)(BaseObject&, BaseObject&);
   
    using Key = std::pair<std::type_index, std::type_index>;
   
    using HitMap = std::map<Key, HitFunctionPtr>;

    HitMap initializeCollisionMap()
    {
        HitMap phm;
        phm[Key(typeid(PlayerObject), typeid(BushObject))] = &playerBush;
        phm[Key(typeid(PlayerObject), typeid(WallObject))] = &playerWall;
        phm[Key(typeid(PlayerObject), typeid(TreeObject))] = &playerTree;
        phm[Key(typeid(PlayerObject), typeid(PortalObject))] = &playerPortal;
        phm[Key(typeid(PlayerObject), typeid(LifeGiftObject))] = &playerLife;
        phm[Key(typeid(PlayerObject), typeid(FreezeGiftObject))] = &playerFreeze;
        phm[Key(typeid(PlayerObject), typeid(WeaponGiftObject))] = &playerWeapon;

        phm[Key(typeid(LaserObject), typeid(PlayerObject))] = &laserPlayer;
        phm[Key(typeid(PlayerObject), typeid(LaserObject))] = &playerLaser;

        phm[Key(typeid(SmallFastEnemyObject), typeid(BallObject))] = &smallEnemyBall;
        phm[Key(typeid(BigSlowEnemyObject), typeid(BallObject))] = &bigEnemyBall;
        phm[Key(typeid(SmallFastEnemyObject), typeid(BombObject))] = &smallEnemyBomb;
        phm[Key(typeid(BigSlowEnemyObject), typeid(BombObject))] = &bigEnemyBomb;
        phm[Key(typeid(BallObject), typeid(SmallFastEnemyObject))] = &ballSmallEnemy;
        phm[Key(typeid(BallObject), typeid(BigSlowEnemyObject))] = &ballBigEnemy;
        phm[Key(typeid(BombObject), typeid(SmallFastEnemyObject))] = &bombSmallEnemy;
        phm[Key(typeid(BombObject), typeid(BigSlowEnemyObject))] = &bombBigEnemy;
        phm[Key(typeid(BallObject), typeid(WallObject))] = &ballWall;
        phm[Key(typeid(BallObject), typeid(TreeObject))] = &ballTree;
        phm[Key(typeid(BallObject), typeid(LifeGiftObject))] = &nothingToDo;
        phm[Key(typeid(BallObject), typeid(FreezeGiftObject))] = &nothingToDo;
        phm[Key(typeid(BallObject), typeid(WeaponGiftObject))] = &nothingToDo;
        phm[Key(typeid(BallObject), typeid(BallObject))] = &nothingToDo;
        phm[Key(typeid(PlayerObject), typeid(BallObject))] = &nothingToDo;
        phm[Key(typeid(BallObject), typeid(PlayerObject))] = &nothingToDo;
        phm[Key(typeid(BombObject), typeid(WallObject))] = &nothingToDo;
        phm[Key(typeid(BombObject), typeid(TreeObject))] = &bombTree;
        phm[Key(typeid(BombObject), typeid(LifeGiftObject))] = &nothingToDo;
        phm[Key(typeid(BombObject), typeid(FreezeGiftObject))] = &nothingToDo;
        phm[Key(typeid(BombObject), typeid(WeaponGiftObject))] = &nothingToDo;

        phm[Key(typeid(SmallFastEnemyObject), typeid(BushObject))] = &nothingToDo;
        phm[Key(typeid(SmallFastEnemyObject), typeid(WallObject))] = &smallEnemyWall;
        phm[Key(typeid(SmallFastEnemyObject), typeid(TreeObject))] = &smallEnemyTree;
        phm[Key(typeid(SmallFastEnemyObject), typeid(PortalObject))] = &smallEnemyPortal;
        phm[Key(typeid(SmallFastEnemyObject), typeid(LifeGiftObject))] = &nothingToDo;
        phm[Key(typeid(SmallFastEnemyObject), typeid(FreezeGiftObject))] = &nothingToDo;
        phm[Key(typeid(SmallFastEnemyObject), typeid(WeaponGiftObject))] = &nothingToDo;
        phm[Key(typeid(SmallFastEnemyObject), typeid(PoisonObject))] = &smallEnemyPoison;

        phm[Key(typeid(BigSlowEnemyObject), typeid(BushObject))] = &nothingToDo;
        phm[Key(typeid(BigSlowEnemyObject), typeid(LifeGiftObject))] = &nothingToDo;
        phm[Key(typeid(BigSlowEnemyObject), typeid(FreezeGiftObject))] = &nothingToDo;
        phm[Key(typeid(BigSlowEnemyObject), typeid(WeaponGiftObject))] = &nothingToDo;
       
        //...
        return phm;
    }

    HitFunctionPtr lookup(const std::type_index& class1, const std::type_index& class2)
    {
        static HitMap collisionMap = initializeCollisionMap();
        auto mapEntry = collisionMap.find(std::make_pair(class1, class2));
        if (mapEntry == collisionMap.end())
        {
            return nullptr;
        }
        return mapEntry->second;
    }

} // end namespace

void processCollision(BaseObject& object1, BaseObject& object2)
{
    auto phf = lookup(typeid(object1), typeid(object2));
    if (!phf)
    {
        throw UnknownCollision(object1, object2);
    }
    phf(object1, object2);
}
