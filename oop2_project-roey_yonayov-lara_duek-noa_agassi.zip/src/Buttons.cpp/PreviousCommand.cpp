#include "Buttons.h/previousCommand.h"
#include <iostream>

StateOptions PreviousCommand::execute()
{
	return Instruction1;
}
