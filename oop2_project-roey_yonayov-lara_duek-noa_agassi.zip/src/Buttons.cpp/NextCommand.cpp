#include "Buttons.h/NextCommand.h"
#include <iostream>

StateOptions NextCommand::execute()
{
	return Instruction2;
}
