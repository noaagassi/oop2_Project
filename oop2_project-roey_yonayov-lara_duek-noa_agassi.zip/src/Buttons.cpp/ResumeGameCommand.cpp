#include "Buttons.h/ResumeGameCommand.h"
#include <iostream>

StateOptions ResumeGameCommand::execute()
{
	return ResumeScrn;
}
