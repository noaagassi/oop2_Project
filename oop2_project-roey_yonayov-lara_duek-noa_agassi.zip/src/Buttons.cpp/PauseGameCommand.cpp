#include "Buttons.h/PauseGameCommand.h"
#include <iostream>

StateOptions PauseGameCommand::execute()
{
	return PauseScrn;
}
 