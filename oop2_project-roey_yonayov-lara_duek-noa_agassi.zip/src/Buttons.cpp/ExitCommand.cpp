#include "Buttons.h/ExitCommand.h"
#include <iostream>

StateOptions ExitCommand::execute()
{
	return Exit;
}
