#include "Buttons.h/InstructionsCommand.h"
#include <iostream>

StateOptions InstructionsCommand::execute()
{
	return InstructionsScrn;
}
