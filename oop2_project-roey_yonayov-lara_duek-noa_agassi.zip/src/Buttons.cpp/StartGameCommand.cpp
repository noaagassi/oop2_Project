#include "Buttons.h/StartGameCommand.h"
#include <iostream>

StateOptions StartGameCommand::execute()
{
	return PlayScrn;
}
