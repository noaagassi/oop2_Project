#include "Buttons.h/MenuCommand.h"

StateOptions MenuCommand::execute()
{
	return MenuScrn;
}
