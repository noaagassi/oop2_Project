#include "Objects.h/BombWeaponObject.h"


BombWeaponObject::BombWeaponObject()
    :PlayerWeaponObject()
{
    m_fireRate = 1.5;
}


void BombWeaponObject::shoot(FlashlightObject flashight)
{
}
