//#include "Objects.h/RegularLaserWeaponObject.h"
//
//
//
//RegularLaserWeaponObject::RegularLaserWeaponObject()
//    :EnemyWeaponObject()
//{
//}
//
//
//void RegularLaserWeaponObject::shoot(FlashlightObject flashight)
//{
//}
