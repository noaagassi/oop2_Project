#include "Objects.h/StaticObject.h"


StaticObject::StaticObject(const sf::Vector2f& initPosition)
	:BaseObject(initPosition)
{

}

StaticObject::StaticObject()
{
}
