//
//#include "Objects.h/MasiveLaserWeaponObject.h"
//
//
//MasiveLaserWeaponObject::MasiveLaserWeaponObject()
//    :EnemyWeaponObject()
//{
//    m_fireRate = 2.0;
//   
//}
//
//
//void MasiveLaserWeaponObject::shoot(FlashlightObject flashight)
//{
//}
//