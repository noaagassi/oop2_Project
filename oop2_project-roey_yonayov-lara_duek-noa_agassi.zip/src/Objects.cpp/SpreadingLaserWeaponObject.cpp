#include "Objects.h/SpreadingLaserWeaponObject.h"



SpreadingLaserWeaponObject::SpreadingLaserWeaponObject()
    :PlayerWeaponObject()
{
    m_fireRate = 3.0;
}

void SpreadingLaserWeaponObject::shoot(FlashlightObject flashight)
{
}
