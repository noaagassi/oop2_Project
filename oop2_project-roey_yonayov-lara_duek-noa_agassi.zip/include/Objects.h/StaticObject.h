#pragma once
#include "BaseObject.h"
#include "FactoryObject.h"


class StaticObject : public BaseObject
{
public:
    StaticObject(const sf::Vector2f& initPosition);
    StaticObject();

private:

};