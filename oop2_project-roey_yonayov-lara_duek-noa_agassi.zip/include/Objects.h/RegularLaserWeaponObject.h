//#pragma once
//#include "EnemyWeaponObject.h"
//
//class RegularLaserWeaponObject : public EnemyWeaponObject
//{
//public:
//    RegularLaserWeaponObject();
//    void shoot(sf::Vector2f) override;
//private:
//    static bool m_registerit;
//};